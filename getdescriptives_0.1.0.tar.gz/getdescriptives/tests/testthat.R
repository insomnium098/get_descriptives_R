library(testthat)
library(getdescriptives)

test_check("getdescriptives")
